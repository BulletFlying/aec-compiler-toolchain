"""AEC C1 compiler bootstrap package."""

__all__ = ["__version__"]

__version__ = "0.1.0"
